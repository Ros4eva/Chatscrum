import { Component, OnInit } from '@angular/core';


@Component({
  selector: '.app-signup',
  template: `<h1>Welcome To Ros4evascrum</h1>
<span> Hello! Welcome to Ros4eva's webpage!, this is actually my first time of handling codes adipisicing elit, sed do eiusmod
tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span>`,
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  userTypes = ['Regular User', 'Project Owner']

  

}